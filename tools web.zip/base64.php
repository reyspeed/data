<!DOCTYPE html>
<html>
<head>
<title>Base64 Tools AAF Exploiter</title>
<!-- Meta Data -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="Description" content="Welcome To Tools Base64 AAF Exploiter">
<!-- Icon -->
<link rel="icon" href="assets/img/Logo2.png">
<style>
    body{
        background-color: black;
        color: white;
        text-align: center;
    }
</style>
</head>

<body>
<div class="head">
    <h1> Tools Base 64 AAF Exploiter
    <img src="https://a.top4top.io/p_1776okki20.png" width="250" alt="">
    
</div>
<br>
<br>
<center>
    
<form name="data" method="post">
<textarea  name="ktg" cols='25' rows='12' placeholder="Input your text"></textarea>
<br>
<br>
<input type="submit" name="en" value="encode">
<input type="submit" name="de" value="decode" ><br><br>


<?php

$md=$_POST['ktg'];
if (isset($_POST['en'])){
	echo"<textarea  cols='25' rows='12'>";
	echo  base64_encode($md);
	echo"</textarea>";
}
else{
	echo"<textarea  cols='25' rows='12'>";
	echo  base64_decode($md);
	echo"</textarea>";
}
?>
    
    
    
</center>




<br>
<br>
<footer style="text-shadow: 0 0 6px #FF0000, 0 0 5px #FF0000, 0 0 5px #FF0000; position:fixed; left:1px; right:0px; top:0px; border-bottom: 3px solid Red ;">
    <center><b><font face="Quicksand" color="black" size="5" style="text-shadow: 0 0 5px #2f2b2b, 0 0 100px #2f2b2b, 0 0 20px #2f2b2b, 0 0 100px #2f2b2b, 0 0 40px #2f2b2b;">
    <font face="Agency FB" color="Red" size="10" style="text-shadow: 0 0 6px black, 0 0 5px black, 0 0 5px black;">

</body>
</html>