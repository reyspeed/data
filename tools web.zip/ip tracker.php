<html>
  <head>
    <title>IP TRACKER</title>

   <style type='text/css'>
   @import url('https://fonts.googleapis.com/css?family=Space+Mono');
     html {
       background: black;
       color: grey;
       font-family: 'Space Mono';
	     font-size: 12px;
	     width: 100%;
     } 
     input[type=text] {
       background: transparent; 
	     color: grey; 
	     border: 1px solid grey; 
	     margin: 5px auto;
	     padding-left: 5px;
	     font-family: 'Space Mono';
	     font-size: 13px;
     }
     input[type=submit] {
	     background: transparent; 
	     color: grey; 
	     border: 1px solid grey; 
	     margin: 5px auto;
	     padding-left: 5px;
	     font-family: 'Space Mono';
	     font-size: 13px;
	     cursor:pointer;
     }
    </style>
  </head>
<body>
<?php
// lu kontol
//
error_reporting(0);
$kntl = $_POST['subm'];
$ip = $_POST['aipi'];
if($kntl) {
  $getURL = json_decode(file_get_contents("https://ipapi.co/".$ip."/json"));
  echo "<br> IP ADDRESS : ".$getURL->ip;
  echo "<br> PROVIDER : ".$getURL->org." <font color='red'>|</font> ASN : ".$getURL->asn;
  echo "<br> COUNTRY : ".$getURL->country_name." <font color='red'>|</font> COUNTRY CODE : ".$getURL->country;
  echo "<br> REGION : ".$getURL->region." <font color='red'>|</font> REGION CODE : ".$getURL->region_code;
  echo "<br> CITY : ".$getURL->city;
	echo "<br> LANGUAGES : ".$getURL->languages;
	echo "<br> CURRENCY : ".$getURL->currency;
	echo "<br> TIME ZONE : ".$getURL->timezone;
	echo "<br> CALLING CODE : ".$getURL->country_calling_code;
  echo "<br> LATITUDE : ".$getURL->latitude;
  echo "<br> LONGITUDE : ".$getURL->longitude;
  echo "<br> VIEW ON GOOGLE MAPS : <br> <iframe width='1100' height='400' src='https://maps.google.com/maps?q=".$getURL->latitude.",".$getURL->longitude."&hl=ID;z=14&amp;output=embed'></iframe>";
} else {
  echo "
 <form method='POST' action=''>
 <input type='text' name='aipi' value='".$_SERVER['REMOTE_ADDR']."'>
 <input type='submit' name='subm' value='Submit'>";
}
  echo "<br><center>Coded By mr.croot</center>"
?>
  </body>
</html>