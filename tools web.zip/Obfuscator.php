<title>Simple PHP Obfuscator</title>
<center>
    <form method="POST">
        <br>
        <textarea name="code" style="width: 615px; height: 141px;"></textarea>
        <br><br>
        <input type="submit" name="enc" value="Encode">
        <input type="submit" name="dec" value="Decode">
    </form>
    <br><br>
<?php
error_reporting(0);
set_time_limit(0);

if(isset($_POST['enc'])) {
    if(isset($_POST['code']) && !empty($_POST['code'])) {
        $obf = base64_encode(gzcompress($_POST['code']));
        echo "<textarea style=\"width: 615px; height: 141px;\" readonly><?=eval(\"?>\".gzuncompress(base64_decode(\"".$obf."\"))); __halt_compiler();?></textarea>";
        echo "</center>";
    }
}

if(isset($_POST['dec'])) {
    if(isset($_POST['code']) && !empty($_POST['code'])) {
        $kode = explode("decode(\"", $_POST['code'])[1];
        $kode = explode("\")", $kode)[0];
        $unobf = ($kode) ? gzuncompress(base64_decode($kode)) : gzuncompress(base64_decode($_POST['code']));
        echo "<textarea style=\"width: 615px; height: 141px;\" readonly>".htmlentities($unobf)."</textarea>";
        echo "</center>";
    }
}