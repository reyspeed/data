<?php 
	error_reporting(0);
	if (!isset($_POST['url'])) {
?>
<html>
<iframe width="0" height="0" scrolling="no" frameborder="no" src="https://w.soundcloud.com/player/?url=https://api.soundcloud.com/tracks/333261487&amp;auto_play=true&amp;hide_related=false&amp;show_comments=true&amp;show_user=false&amp;show_reposts=false&amp;visual=true"></iframe>
<head>
<style type="text/css">body, a:hover {cursor: url(http://cur.cursors-4u.net/cursors/cur-9/cur864.ani), url(http://cur.cursors-4u.net/cursors/cur-9/cur864.png), progress !important;}</style><a href="http://www.cursors-4u.com/cursor/2011/11/22/night-diamond-bloody-red-link-select-max.html" target="_blank" title="Night Diamond Bloody Red - Link Select Max"><img src="http://cur.cursors-4u.net/cursor.png" border="0" alt="Night Diamond Bloody Red - Link Select Max" style="position:absolute; top: 0px; right: 0px;" /></a>
	<title>Admin Page Finder PHP</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body bgcolor="black">
<font color="red">
	<center>
<img src="http://www.marvelmedilinks.com/Cvar.png" />
		<form method="post">
			<h1>AdminFinder</h1>
			<input type="text" name="url" placeholder="http://www.Cvar1984.sarahah.com"><input type="submit" value="find">
		</form>
<a href="http://www.Cvar1984.sarahah.com">Feedback</a>
	</center>
</font>
</body>
</html>
<script src="//yourjavascript.com/1171704334/efek-salju-faisal.js"></script>
<?php
} else {
	$url = $_POST['url']."/";


$adminpages = array('admin.php','cpanel','whm','redaktur','redakturweb','admin/','admin/login.jsp','administrator/','moderator/','webadmin/','adminarea/','bb-admin/','adminLogin/','admin_area/','panel-administracion/','instadmin/','memberadmin/','administratorlogin/','adm/','admin/account.php','admin/index.php','admin/login.php','admin/admin.php','admin/account.php','joomla/administrator','login.php',
'admin_area/admin.php','admin_area/login.php','siteadmin/login.php','siteadmin/index.php','siteadmin/login.html','admin/account.html','admin/index.html','admin/login.html','admin/admin.html','admin_area/index.php','bb-admin/index.php','bb-admin/login.php','bb-admin/admin.php','admin/home.php','admin_area/login.html','admin_area/index.html','admin/controlpanel.php','admincp/index.asp','admincp/login.asp','admincp/index.html','admin/account.html','adminpanel.html','webadmin.html','webadmin/index.html','webadmin/admin.html','webadmin/login.html','admin/admin_login.html','admin_login.html','panel-administracion/login.html','admin/cp.php','cp.php','administrator/index.php','administrator/login.php','nsw/admin/login.php','webadmin/login.php','admin/admin_login.php','admin_login.php','administrator/account.php','administrator.php','admin_area/admin.html','pages/admin/admin-login.php','admin/admin-login.php','admin-login.php','bb-admin/index.html','bb-admin/login.html','bb-admin/admin.html','admin/home.html','modelsearch/login.php','moderator.php','moderator/login.php','moderator/admin.php','account.php','pages/admin/admin-login.html','admin/admin-login.html','admin-login.html','controlpanel.php','admincontrol.php',
'admin/adminLogin.html','adminLogin.html','admin/adminLogin.html','home.html','rcjakar/admin/login.php','adminarea/index.html','adminarea/admin.html','webadmin.php','webadmin/index.php','webadmin/admin.php','admin/controlpanel.html','admin.html','admin/cp.html','cp.html','adminpanel.php','moderator.html','administrator/index.html','administrator/login.html','user.html','administrator/account.html','administrator.html','login.html','modelsearch/login.html','moderator/login.html','adminarea/login.html','panel-administracion/index.html','panel-administracion/admin.html','modelsearch/index.html','modelsearch/admin.html','admincontrol/login.html','adm/index.html','adm.html','moderator/admin.html','user.php','account.html','controlpanel.html','admincontrol.html','panel-administracion/login.php','wp-login.php','adminLogin.php','admin/adminLogin.php','home.php','adminarea/index.php','adminarea/admin.php','adminarea/login.php','panel-administracion/index.php','panel-administracion/admin.php','modelsearch/index.php','modelsearch/admin.php','admincontrol/login.php','adm/admloginuser.php','admloginuser.php','admin2.php','admin2/login.php','admin2/index.php','adm/index.php','adm.php','affiliate.php','adm_auth.php','memberadmin.php','administratorlogin.php');
?>
<html>
<iframe width="0" height="0" scrolling="no" frameborder="no" src="https://w.soundcloud.com/player/?url=https://api.soundcloud.com/tracks/333261487&amp;auto_play=true&amp;hide_related=false&amp;show_comments=true&amp;show_user=false&amp;show_reposts=false&amp;visual=true"></iframe>
<<head>
<style type="text/css">body, a:hover {cursor: url(http://cur.cursors-4u.net/cursors/cur-9/cur864.ani), url(http://cur.cursors-4u.net/cursors/cur-9/cur864.png), progress !important;}</style><a href="http://www.cursors-4u.com/cursor/2011/11/22/night-diamond-bloody-red-link-select-max.html" target="_blank" title="Night Diamond Bloody Red - Link Select Max"><img src="http://cur.cursors-4u.net/cursor.png" border="0" alt="Night Diamond Bloody Red - Link Select Max" style="position:absolute; top: 0px; right: 0px;" /></a>
	<title>Admin Page Finder PHP</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body bgcolor="black">
	<center>
<img src="http://www.marvelmedilinks.com/Cvar.png" />
<font color="red">
			<h1>Admin Finder</h1>
			<h3>Scanning <?=htmlspecialchars($url)?></h3>
</font>
			<?php
				foreach($adminpages as $page) {
					$caminho = $url.$page;
					$retornado = get_headers($caminho);

					if (eregi('200', $retornado[0])) {
						echo "<font color='lime'><p class='ok'><b>[+] ".$url.$page."</b></p></font>";
					} else {
						echo "<font color='red'><p class='no'>[-] ".$url.$page."</p></font>";
					}
				}
			?>
<a href="http://www.Cvar1984.sarahah.com">Feedback</a>
	</center>
</body>
</html>
<script src="//yourjavascript.com/1171704334/efek-salju-faisal.js"></script>
<?php
}
?>