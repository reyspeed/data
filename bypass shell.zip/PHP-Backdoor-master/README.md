# PHP Shell Backdoor

### 0byt3m1n1 V 2.0
0byt3m1n1 is a mini backdoor for bypassing 403 forbidden and this backdoor is not detected by malware scanners.
