<style type="text/css">
<!--
input {
    border-right: 1px solid #000;
    border-width: 1px;
    border-style: solid;
    border-color: #000;
    background-color: #333;
    font: 9pt courier;
    color: #FFF;
}
body { background: url("https://i.pximg.net/c/600x1200_90_webp/img-master/img/2015/11/10/00/02/59/53472906_p0_master1200.jpg") no-repeat center center fixed; -webkit-background-size: cover; -moz-background-size: cover; -o-background-size: cover; background-size: cover; color: white;
}
</style>
<form method='POST'>
<title>Wordpress Plugins Check</title>

<center><b><b><font face='courier' size='5' color='white'><b>WORDPRESS PLUGINS MASS CHECKER</b><br>
<br>
</font><br><br>
<center><textarea name='site' cols='70' rows='10' style="background-color: rgb(1, 1, 1); color: rgb(200, 200, 200); border: 1px solid rgb(200, 200, 200); outline: medium none; font-size: 11px; border-radius: 3px 3px 3px 3px; padding: 2px 3px; margin: 0px 0px 0px -1px;" >
https://www.synganteng.go.id
</textarea></center>
<br>
<center><input type='submit' class='irhebi' value='Scan n0w!!' name='start'><br></center>

</form>
<font color="#000000"><b>
<p align="center"><font face="courier" color="white" size="1"><hr><center>&copy;5YN15T3R_742</a>


</font></u></p>
<?
/* Coded By 5YN15T3R_742
Don't Change Copy Right
*/
    @set_time_limit(0);
    $irh = explode("\r\n", $_POST['site']);
    $path = array('revslider','gravity-forms','xaisyndicate','sell-downloads','zilla-likes','formcraft','site-import','abtest','recent-backups','imdb-widget','recent-backups','hb-audio-gallery-lite','woocommerce-product-options','jquery-html5-file-upload','mdocs-posts','brandfolder','wysija-newsletters');


    if($_POST['start'])
    {
        foreach($irh as $site)
        {
            foreach($path as $plug)
                        {
            $gcurl = @file_get_contents($site);
                                if(eregi(".$plug.", $gcurl))            
                                {
                echo "<br><font color='green' size='2'>".$plug."</font><font color='white' size='2'> Found !! ==> ".$site."</font>";
            }else{                echo "<br><font color='red' size='2'>".$plug."</font><font color='white' size='2'> NOT Found njeng</font>";}
        }
        }
        
    }
    
?>