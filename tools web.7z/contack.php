<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
  <div class="contact-form">
    <h1>Contact Us</h1>
    <div class="txtb">
      <label>Full Name :</label>
      <input type="text" name="" value="" placeholder="Enter Your Name">
    </div>

    <div class="txtb">
      <label>Email :</label>
      <input type="email" name="" value="" placeholder="Enter Your Email">
    </div>

    <div class="txtb">
      <label>Phone Number :</label>
      <input type="text" name="" value="" placeholder="Enter Your Phone Number">
    </div>

    <div class="txtb">
      <label>Message :</label>
      <textarea></textarea>
    </div>
    <a class="btn">Send</a>
  </div>
  </body>
</html>
