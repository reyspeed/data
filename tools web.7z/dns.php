
<!DOCTYPE html>
<html>
<head>
<title>DNS Lookup Tools </title>
<!-- Meta Data  -->
<meta charset="utf-8">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="tools dnslookup">
<!-- Link -->
<link rel="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQqEyYRMCB8RMMWWE_gbr2vq5G_asZUPzcIPg&usqp=CAU" href="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQqEyYRMCB8RMMWWE_gbr2vq5G_asZUPzcIPg&usqp=CAU">

<style>
    body{
        background-color:black;
        color: white;
        text-align: center;
    }
</style>
</head>

<body>
<div class="head">
<center><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQqEyYRMCB8RMMWWE_gbr2vq5G_asZUPzcIPg&usqp=CAU" height="200" width="200" /></center> <body class="fade" style=" overflow: hidden; "> <br><br> 
<h1> DNS LOCKUP TOOLS</h1>
</div>

<table cellpadding="5" cellspacing="0" border="0" style="width: 100%; border-collapse: collapse" align="center">
  <tr>
    <td>
      <table cellpadding="2" cellspacing="0" style="border-collapse: collapse">
        <tr>
          <td>
            <b>masukan url tod:</b>
          </td>
          <td>
            <input type="text" name="url" value="" size="13" />
          </td>
          <td>
            <input type="button" value="Show" onclick="OnSubmitPluginInput(this,'https://www.webtoolhub.com/plugins/wt561347-mx-ns-soa-record-lookup.aspx');" />
          </td>
       </tr>
       <tr>
         <td>
         </td>
         <td colspan="2" style="font-size: 9pt;">
           (www.xnxx.com)
         </td>
       </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td>
      <iframe name="pluginframe561347" frameborder="0" style="width: 100%; height: 300px"></iframe>
    </td>
  </tr>
  <tr>
    <td style="font-size: 0pt; font-family: Verdana, Arial;">
      Powered by: <a href="https://www.webtoolhub.com/tn561347-mx-ns-soa-record-lookup.aspx" title="Free Webmaster Tools">WebToolHub.com</a>
    </td>
  </tr>
</table>
<script type="text/javascript" src="https://secure.webtoolhub.com/plugin.axd"></script>

<br>
<br>

<hr>
</body>
</html>