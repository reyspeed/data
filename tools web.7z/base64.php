<center>
<pre>
 <FORM method='POST'> 
 <label><b>Base64 encode/decode:</b></label> 
 <textarea name='base64' rows='5' cols='71'></textarea><br>  
 <input type='submit' name='submit' value='Encode'> 
 <input type='submit' name='submit2' value='Decode'>  
</pre>

<?php 
IF (isset($_POST['submit'])) { 
  $base64 = $_POST['base64']; 
  $encode = base64_encode($base64); 
  echo "Encode: ".$encode;
} 
IF (isset($_POST['submit2'])) { 
  $base64 = $_POST['base64']; 
  $decode = base64_decode($base64); 
  echo "Decode: ".$decode;
} 
?>