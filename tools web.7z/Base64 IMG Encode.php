<form name="data" method="post">
<textarea name="url" style="height:250px;width:500px"  placeholder="Input your image url"></textarea><br><br>
<input type="submit" name='go' value="GASCOK">
<input type="reset"  value="CANCEL">

<?php
error_reporting(E_ALL ^ ( E_NOTICE | E_WARNING ));
$ya=$_POST['go'];
$co=$_POST['url'];

if($ya){
$image = ($co);
$type = pathinfo($image, PATHINFO_EXTENSION);
$data = file_get_contents($image);
$dataUri = 'data:image/' . $type . ';base64,' . base64_encode($data);
echo"<center><textarea cols='50' rows='12'>$dataUri</textarea></center>";	
}
?>