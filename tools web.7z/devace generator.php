<!DOCTYPE html>
<html>
<head>
<title>SC DEFACE GENERATOR GRAYHAT</title>
<!-- Meta Data -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="Description" content=DEFACE GENERATOR GRAYHAT">
<!-- Icon -->
<link rel="icon" href="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQqEyYRMCB8RMMWWE_gbr2vq5G_asZUPzcIPg&usqp=CAU">
<style>
    body{
        background-color: black;
        color: white;
        text-align: center;
    }
</style>
    <meta property="og:image" content="http://al-list.com/index.png">
    <meta property="og:url" content="http://al-list.com/index.php">
</head>
<body>

<center>
    <h1 style="margin-top: 20px;margin-bottom: 50px;">[+] Script Deface Generator Grayhat [+]</h1>
    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQqEyYRMCB8RMMWWE_gbr2vq5G_asZUPzcIPg&usqp=CAU" width="250" alt="">
    
<!-- https://www.google.com/maps/place/-7.7082+114.0008 -->
    <!-- <div class="col-lg-12">
            <div id="loading">
                <img src="http://v6.player.abacast.net/assets/images/loading.gif" style="width: 5%"><br>
            Mencari ...
            </div> 
        </center>
    </div> -->

    <div class="col-lg-12">
        <div class="row">
            <div class="col-lg-6">
              <div class="form-group">
                <h4>Options : </h4>
              </div>
              <div class="form-group">
                <table class="table">
                  <tr>
                    <td>
                        <label>URL Gambar : </label>
                        <input type="text" id="gambar" class="form-control" placeholder="https://g.top4top.io/p.jpg">
                    </td>
                    <td>
                      <label>Warna Background: </label>
                      <input type="text" id="background" class="form-control" placeholder="#00f00 / YELLOW / RED">
                    </td>
                    <td>
                      <label>URL icon Gambar : </label>
                        <input type="text" id="icon" class="form-control" placeholder="http://al-list.com/
                        index.png">
                    </td>
                  </tr>
                </table>
              </div>
              <div class="form-group">
                <table class="table">
                  <tr>
                    <td>
                        <label>Nama Samaran (NICK) : </label>
                        <input type="text" id="nick" class="form-control" placeholder="AAF Exploiter">
                    </td>
                    <td>
                      <label>Warna : </label>
                      <input type="text" id="warna_nick" class="form-control" placeholder="#00f00 / YELLOW / RED">
                    </td>
                    <td>
                      <label>Type Font : </label>
                        <select id="font_nick" class="form-control">
                          <option value="Calibri">Calibri</option>
                          <option value="Times New Roman">Times New Roman</option>
                          <option value="Times">Times</option>
                          <option value="serif">serif</option>
                          <option value="Arial">Arial</option>
                          <option value="Helvetica">Helvetica</option>
                          <option value="sans-serif">sans-serif</option>
                          <option value="Comic Sans MS">Comic Sans MS</option>
                          <option value="Impact">Impact</option>
                          <option value="Lucida Sans Unicode">Lucida Sans Unicode</option>
                          <option value="Tahoma">Tahoma</option>
                          <option value="Trebuchet MS">Trebuchet MS</option>
                          <option value="Verdana">Verdana</option>
                          <option value="Courier New">Courier New</option>
                          <option value="Lucida Console">Lucida Console</option>
                        </select>
                    </td>
                  </tr>
                </table>
              </div>
              <div class="form-group">
                <table class="table">
                  <tr>
                    <td>
                        <label>Nama Team : </label>
                        <input type="text" id="tim" class="form-control" placeholder="[ AAF Exploiter |•| Public ]">
                    </td>
                    <td>
                      <label>Warna : </label>
                      <input type="text" id="warna_tim" class="form-control" placeholder="#00f00 / YELLOW / RED">
                    </td>
                    <td>
                      <label>Type Font : </label>
                        <select id="font_tim" class="form-control">
                          <option value="Calibri">Calibri</option>
                          <option value="Times New Roman">Times New Roman</option>
                          <option value="Times">Times</option>
                          <option value="serif">serif</option>
                          <option value="Arial">Arial</option>
                          <option value="Helvetica">Helvetica</option>
                          <option value="sans-serif">sans-serif</option>
                          <option value="Comic Sans MS">Comic Sans MS</option>
                          <option value="Impact">Impact</option>
                          <option value="Lucida Sans Unicode">Lucida Sans Unicode</option>
                          <option value="Tahoma">Tahoma</option>
                          <option value="Trebuchet MS">Trebuchet MS</option>
                          <option value="Verdana">Verdana</option>
                          <option value="Courier New">Courier New</option>
                          <option value="Lucida Console">Lucida Console</option>
                        </select>
                    </td>
                  </tr>
                </table>
              </div>
              <div class="form-group">
                <table class="table">
                  <tr>
                    <td>
                        <label>Kata 1 : </label>
                        <input type="text" id="kata1" class="form-control" placeholder="AAF Exploiter Gans:v">
                    </td>
                    <td>
                      <label>Warna : </label>
                      <input type="text" id="warna_kata1" class="form-control" placeholder="#00f00 / YELLOW / RED">
                    </td>
                    <td>
                      <label>Type Font : </label>
                        <select id="font_kata1" class="form-control">
                          <option value="Calibri">Calibri</option>
                          <option value="Times New Roman">Times New Roman</option>
                          <option value="Times">Times</option>
                          <option value="serif">serif</option>
                          <option value="Arial">Arial</option>
                          <option value="Helvetica">Helvetica</option>
                          <option value="sans-serif">sans-serif</option>
                          <option value="Comic Sans MS">Comic Sans MS</option>
                          <option value="Impact">Impact</option>
                          <option value="Lucida Sans Unicode">Lucida Sans Unicode</option>
                          <option value="Tahoma">Tahoma</option>
                          <option value="Trebuchet MS">Trebuchet MS</option>
                          <option value="Verdana">Verdana</option>
                          <option value="Courier New">Courier New</option>
                          <option value="Lucida Console">Lucida Console</option>
                        </select>
                    </td>
                  </tr>
                </table>
              </div>
              <div class="form-group">
                <table class="table">
                  <tr>
                    <td>
                        <label>Kata 2 : </label>
                        <input type="text" id="kata2" class="form-control" placeholder="Touched By AAF Exploiter">
                    </td>
                    <td>
                      <label>Warna : </label>
                      <input type="text" id="warna_kata2" class="form-control" placeholder="#00f00 / YELLOW / RED">
                    </td>
                    <td>
                      <label>Type Font : </label>
                        <select id="font_kata2" class="form-control">
                          <option value="Calibri">Calibri</option>
                          <option value="Times New Roman">Times New Roman</option>
                          <option value="Times">Times</option>
                          <option value="serif">serif</option>
                          <option value="Arial">Arial</option>
                          <option value="Helvetica">Helvetica</option>
                          <option value="sans-serif">sans-serif</option>
                          <option value="Comic Sans MS">Comic Sans MS</option>
                          <option value="Impact">Impact</option>
                          <option value="Lucida Sans Unicode">Lucida Sans Unicode</option>
                          <option value="Tahoma">Tahoma</option>
                          <option value="Trebuchet MS">Trebuchet MS</option>
                          <option value="Verdana">Verdana</option>
                          <option value="Courier New">Courier New</option>
                          <option value="Lucida Console">Lucida Console</option>
                        </select>
                    </td>
                  </tr>
                </table>
              </div>
              <div class="form-group">
                <table class="table">
                  <tr>
                    <td>
                        <label>Kata 3 : </label>
                        <input type="text" id="kata3" class="form-control" placeholder="Sabrek Chanel AAF Exploiter">
                    </td>
                    <td>
                      <label>Warna : </label>
                      <input type="text" id="warna_kata3" class="form-control" placeholder="#00f00 / YELLOW / RED">
                    </td>
                    <td>
                      <label>Type Font : </label>
                        <select id="font_kata3" class="form-control">
                          <option value="Calibri">Calibri</option>
                          <option value="Times New Roman">Times New Roman</option>
                          <option value="Times">Times</option>
                          <option value="serif">serif</option>
                          <option value="Arial">Arial</option>
                          <option value="Helvetica">Helvetica</option>
                          <option value="sans-serif">sans-serif</option>
                          <option value="Comic Sans MS">Comic Sans MS</option>
                          <option value="Impact">Impact</option>
                          <option value="Lucida Sans Unicode">Lucida Sans Unicode</option>
                          <option value="Tahoma">Tahoma</option>
                          <option value="Trebuchet MS">Trebuchet MS</option>
                          <option value="Verdana">Verdana</option>
                          <option value="Courier New">Courier New</option>
                          <option value="Lucida Console">Lucida Console</option>
                        </select>
                    </td>
                  </tr>
                </table>
              </div>
              <div class="form-group">
                <table class="table">
                  <tr>
                    <td>
                        <label>Thank's To : </label>
                        <input type="text" id="thanks" class="form-control" placeholder="AAF">
                    </td>
                    <td>
                      <label>Warna : </label>
                      <input type="text" id="warna_thanks" class="form-control" placeholder="#00f00 / YELLOW / RED">
                    </td>
                    <!-- <td>
                      <label>Nama Samaran (NICK) : </label>
                        <input type="text" id="nick" class="form-control" placeholder="Bang4Y1N">
                    </td> -->
                  </tr>
                </table>
              </div>
              <div class="form-group">
                <button class="btn btn-danger" onclick="buat_euy()"> Buat Cepat</button>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="form-group">
                <h4>Hasil : </h4>
              </div>
              <div class="form-group">
                <label>Script : Monggo Di Copy Mates</label>
                <textarea class="form-control" id="hasil" rows="23"></textarea>
              </div>
            </div>
        </div>
    </div>

    
    <div class="col-lg-12" style="margin-bottom: 20px;margin-top: 20px">

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<script
  src="https://code.jquery.com/jquery-3.3.1.js"
  integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
  crossorigin="anonymous">
</script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>

<script>
  function buat_euy() {
    var gambar = $('#gambar').val();
    var icon = $('#icon').val();
    var background = $('#background').val();

    var nick = $('#nick').val();
    var warna_nick = $('#warna_nick').val();
    var font_nick = $('#font_nick').val();

    var tim = $('#tim').val();
    var warna_tim = $('#warna_tim').val();
    var font_tim = $('#font_tim').val();

    var kata1 = $('#kata1').val();
    var warna_kata1 = $('#warna_kata1').val();
    var font_kata1 = $('#font_kata1').val();

    var kata2 = $('#kata2').val();
    var warna_kata2 = $('#warna_kata2').val();
    var font_kata2 = $('#font_kata2').val();

    var kata3 = $('#kata3').val();
    var warna_kata3 = $('#warna_kata3').val();
    var font_kata3 = $('#font_kata3').val();

    var thanks = $('#thanks').val();
    var warna_thanks = $('#warna_thanks').val();

    var output = '<!DOCTYPE html><html><head><title>Hacked By '+nick+' - '+tim+'</title><meta charset="UTF-8"><meta name="author" content="'+nick+'"><meta name="viewport" content="width=device-width, initial-scale=1.0"><meta name="description" content="'+kata1+'"><meta name="keywords" content="'+nick+' - '+tim+'"><link rel="shortcut icon" type="image/x-icon" href="'+icon+'" /> --><meta property="og:image" content="'+gambar+'"><style>body{background: '+background+'}h1{color:'+warna_nick+';font-family: '+font_nick+'}h2{color:'+warna_tim+';font-family: '+font_tim+'}.kata1{color:'+warna_kata1+';font-family: '+font_kata1+'}.kata2{color:'+warna_kata2+';font-family: '+font_kata2+'}.kata3{color:'+warna_kata3+';font-family: '+font_kata3+'}</style></head><body><center><img src="'+gambar+'" style="width: 20%"><br><h1>Hacked By '+nick+'</h1><h2>'+tim+'</h2><p class="kata1">'+kata1+'</p><p class="kata2">'+kata2+'</p><p class="kata3">'+kata3+'</p><br><br><br><br><marquee><b style="color: white;font-size: 18px">.:: </b> <b style="color: '+warna_thanks+';font-size:20px">'+thanks+'</b> <b style="color: white;font-size: 18px"> ::.</b></marquee></center></body></html>'; 
    $('#hasil').val(output);
  }
</script>

</body>
</html>