<?php
// IP Reverse

// c0ded by shutdown57
// indonesianpeople.shutdown57@gmail.com
//fb.com/JKT48.co
function s57_curl($domen){
	$c = curl_init();
	$curl = array(
		CURLOPT_URL=>"http://viewdns.info/reverseip/?host=".$domen."&t=1",
		CURLOPT_USERAGENT=>"User-Agent=Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0",
		CURLOPT_RETURNTRANSFER=>1,
		CURLOPT_SSL_VERIFYPEER=>0,
		CURLOPT_HEADER=>0,
		CURLOPT_FOLLOWLOCATION=>1);
	curl_setopt_array($c,$curl);
	$e = curl_exec($c);
	curl_close($c);
	return $e;
}
function s57_p($pemisah,$string){
    return explode(chr(1),str_replace($pemisah,chr(1),$string));
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>ReverSe IP - shutdown57</title>
<meta name="author" content="shutdown57">
<meta name="description" content="ReverSe IP shutdown57">
<meta name="keywords" content="shutdown57">
</head>
<style type="text/css">
	body{background:#000;color:#eee;}table{border:1px solid #fff;border-collapse: collapse;}input{color:#fff;border:1px solid #fff;background: transparent;}
</style>
<body>
<center>
<h3>IP Reverse - shutdown57</h3>
<form method="post">
	<input type="text" name="domain" placeholder="IP/Domain"><input type="submit" name="sbmt" value="Reverse!">
</form>
<br><br><hr>
</body>
</html>
<?php
if(isset($_POST['sbmt'])){
echo "Result for : " .$_POST['domain'];
$r = s57_p(array('<table border="1">','<table width="1000" align="center" border="0">'),s57_curl($_POST['domain']));
echo "<table border=1>";
echo $r[1];
echo "</table></center>";
}
?>